# Сводка метрик этапа 4 по трём опытам (без Milvus/Ollama).
# Положить в scripts/stage4_eval/. Запуск: powershell -ExecutionPolicy Bypass -File scripts\stage4_eval\run_summary.ps1
$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Push-Location $ProjectRoot
$env:PYTHONIOENCODING = "utf-8"
python scripts\stage4_eval\reports\build_stage4_summary.py @args
$code = $LASTEXITCODE
Pop-Location
exit $code

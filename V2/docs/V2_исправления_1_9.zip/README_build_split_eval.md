# Сборка eval_questions_split.json и eval_qrels_split.json

Распаковать в корень проекта (рядом с папкой V2). Добавляются только 2 файла:
- V2/scripts/build_split_eval/build.py
- V2/configs/pipeline_manual_merged_split.json

Нужно: Python 3.9+, openpyxl (`pip install openpyxl`).
Вход: V2/data/rag_eval_questions/Вопросы_разбиение_все_главы.xlsx, eval_questions.json, V2/data/chunked_merged_manual.

## 1. Сборка (из корня проекта)
    python V2/scripts/build_split_eval/build.py --project-root .
Повторно, если файлы уже есть:
    python V2/scripts/build_split_eval/build.py --project-root . --overwrite

Результат в V2/data/rag_eval_questions/:
- eval_questions_split.json — 720 вопросов (268 исходных + 452 части)
- eval_qrels_split.json — qrels схемы 1.0
- split_build_report.md — несовпадения, дубли, вопросы с изображениями

Ожидаемо: "facts": 1733, "facts_without_chunk": 0, "validation": "passed".

## 2. Проверка через пайплайн
    python V2/scripts/run_pipeline.py validate --config V2/configs/pipeline_manual_merged_split.json

## 3. Оценка поиска на новом наборе (Milvus уже загружен для manual_merged)
    python V2/scripts/run_pipeline.py search --config V2/configs/pipeline_manual_merged_split.json --mode base
    python V2/scripts/run_pipeline.py evaluate --config V2/configs/pipeline_manual_merged_split.json --mode base --input V2/results/retrieval/split/<папка из вывода search>/retrieval.json

Старые eval_questions.json и retrieval_qrels.json не изменяются.
Если вы правите Excel — просто перезапустите шаг 1 с --overwrite.

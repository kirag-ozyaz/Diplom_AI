def print_run_done(result):
    import json
    print(json.dumps(result,ensure_ascii=False,indent=2,default=str))

def info(message):
    print(str(message))

def warning(message):
    import sys
    print('Предупреждение: '+str(message),file=sys.stderr)

def error(message):
    import sys
    print('Ошибка: '+str(message),file=sys.stderr)

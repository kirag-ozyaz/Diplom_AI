"""Общий модуль V2; внутренний API старого проекта не воспроизводится."""
from pathlib import Path
import sys
_V2 = next(p for p in Path(__file__).resolve().parents if (p/'configs/pipeline.json').is_file())
sys.path.insert(0, str(_V2/'src'))
from retrieval_eval.common import path_in, ensure, inside, run_id

def retrieval_dir(project_root, identifier=None):
    root=Path(project_root).resolve()
    v2=root/'V2'
    path=path_in(root,'V2/results/retrieval/'+(identifier or run_id()))
    ensure(inside(path,v2/'results/retrieval'),'Неверный путь retrieval')
    return path

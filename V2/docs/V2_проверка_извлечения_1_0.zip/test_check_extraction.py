import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
SCRIPT=HERE/'check_extraction.py'
if not SCRIPT.exists(): SCRIPT=HERE/'V2/scripts/check_extraction.py'
spec=importlib.util.spec_from_file_location('auditor',SCRIPT)
a=importlib.util.module_from_spec(spec); spec.loader.exec_module(a)
W=a.W; M=a.M; A=a.A; R=a.R

def doc_xml(body):
    return ('<w:document xmlns:w="'+W+'" xmlns:m="'+M+'" xmlns:a="'+A+'" xmlns:r="'+R+'"><w:body>'+body+'</w:body></w:document>').encode()
def para(t): return '<w:p><w:r><w:t>'+t+'</w:t></w:r></w:p>'

class AuditTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name); self.raw=self.root/'data/raw'; self.raw.mkdir(parents=True)
        self.extracted=self.root/'V2/results/retrieval/documents_fixture'; self.folder=self.extracted/'document'; self.folder.mkdir(parents=True)
        self.assets=self.folder/'assets'; self.assets.mkdir()
    def make(self,body=None,md='1.1.1. Test text\n',extras=None):
        self.src=self.raw/'sample.docx'
        with ZipFile(self.src,'w') as z:
            z.writestr('word/document.xml',doc_xml(body or para('1.1.1. Test text')))
            for k,v in (extras or {}).items(): z.writestr(k,v)
        self.dest=self.folder/'document.md'; self.dest.write_text(md,encoding='utf-8')
        self.rec=dict(source_file='data/raw/sample.docx',source_sha256=a.sha(self.src.read_bytes()),markdown=self.dest.relative_to(self.root).as_posix(),warnings=[],extraction_review_status='unreviewed')
        self.commit()
    def commit(self):
        (self.folder/'source.json').write_text(json.dumps(self.rec),encoding='utf-8')
        (self.extracted/'extraction.json').write_text(json.dumps(dict(schema_version='v2-documents-1',documents=[self.rec])),encoding='utf-8')
    def run_audit(self): return a.audit(self.root,self.extracted,self.raw)
    def codes(self): return self.run_audit()['issue_counts']
    def test_clean_and_read_only(self):
        self.make(); before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        report=self.run_audit(); self.assertEqual(report['status'],'technical_checks_passed')
        self.assertFalse(report['automatically_approved_for_chunking'])
        self.assertTrue(all(p.read_bytes()==b for p,b in before.items()))
    def test_source_hash(self):
        self.make(); self.src.write_bytes(self.src.read_bytes()+b'tampered')
        self.assertIn('source_sha256_mismatch',self.codes())
    def test_missing_paragraph(self):
        self.make(); self.dest.write_text('1.1.1. Different text\n',encoding='utf-8')
        self.assertIn('paragraph_text_occurrences_not_confirmed',self.codes())
    def test_clause_order(self):
        self.make(para('1.1.1. First')+para('1.1.2. Second'),'1.1.2. Second\n\n1.1.1. First\n')
        self.assertIn('literal_clause_sequence_differs',self.codes())
    def test_automatic_numbering(self):
        self.make('<w:p><w:pPr><w:numPr><w:numId w:val="1"/></w:numPr></w:pPr><w:r><w:t>Text</w:t></w:r></w:p>','Text\n')
        self.assertIn('automatic_numbering_not_reconstructed',self.codes())
    def test_style_numbering(self):
        styles='<w:styles xmlns:w="'+W+'"><w:style w:styleId="List"><w:pPr><w:numPr/></w:pPr></w:style></w:styles>'
        self.make('<w:p><w:pPr><w:pStyle w:val="List"/></w:pPr><w:r><w:t>Text</w:t></w:r></w:p>','Text\n',{'word/styles.xml':styles})
        self.assertIn('automatic_numbering_not_reconstructed',self.codes())
    def test_table_cells(self):
        table='<w:tbl><w:tr><w:tc>'+para('Header')+'</w:tc></w:tr><w:tr><w:tc>'+para('123')+'</w:tc></w:tr></w:tbl>'
        self.make(para('1.1.1. Test text')+table,'1.1.1. Test text\n\n| Header |\n| --- |\n| 123 |\n')
        self.assertNotIn('table_cells_or_order_not_confirmed',self.codes())
        self.dest.write_text(self.dest.read_text().replace('123','124'),encoding='utf-8')
        self.assertIn('table_cells_or_order_not_confirmed',self.codes())
    def test_merged_xml(self):
        table='<w:tbl><w:tr><w:tc><w:tcPr><w:gridSpan w:val="2"/></w:tcPr>'+para('Header')+'</w:tc></w:tr></w:tbl>'
        self.make(para('1.1.1. Test text')+table,'1.1.1. Test text\n\n| Header |\n| --- |\n\n[table](assets/table.xml)\n')
        (self.assets/'table.xml').write_text('<w:tbl xmlns:w="'+W+'"><w:tr><w:tc><w:tcPr><w:gridSpan w:val="2"/></w:tcPr>'+para('Header')+'</w:tc></w:tr></w:tbl>',encoding='utf-8')
        self.assertNotIn('merged_table_xml_missing_or_changed',self.codes())
        self.assertIn('merged_table_visual_layout_requires_review',self.codes())
        (self.assets/'table.xml').write_text('<w:tbl xmlns:w="'+W+'"/>',encoding='utf-8')
        self.assertIn('merged_table_xml_missing_or_changed',self.codes())
    def test_formula_xml(self):
        math='<m:oMath><m:r><m:t>x</m:t></m:r></m:oMath>'
        self.make(para('1.1.1. Test text')+'<w:p>'+math+'</w:p>','1.1.1. Test text\n\n[formula](assets/f.xml)\n')
        (self.assets/'f.xml').write_text('<m:oMath xmlns:m="'+M+'"><m:r><m:t>x</m:t></m:r></m:oMath>',encoding='utf-8')
        self.assertNotIn('formula_xml_missing_or_changed',self.codes())
        (self.assets/'f.xml').write_text('<m:oMath xmlns:m="'+M+'"/>',encoding='utf-8')
        self.assertIn('formula_xml_missing_or_changed',self.codes())
    def test_images_and_hash(self):
        image=b'fixture image bytes'; filename=a.sha(image)+'.png'
        rels='<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="image" Target="media/a.png"/></Relationships>'
        self.make(para('1.1.1. Test text')+'<w:p><w:r><a:blip r:embed="rId1"/></w:r></w:p>','1.1.1. Test text\n\n![](assets/'+filename+')\n',{'word/_rels/document.xml.rels':rels,'word/media/a.png':image})
        asset=self.assets/filename; asset.write_bytes(image)
        self.assertNotIn('image_content_or_occurrences_differ',self.codes())
        asset.write_bytes(b'bad'); codes=self.codes()
        self.assertIn('resource_content_hash_mismatch',codes); self.assertIn('image_content_or_occurrences_differ',codes)
    def test_missing_link(self):
        self.make(md='1.1.1. Test text\n\n![](assets/missing.png)\n')
        self.assertIn('linked_resource_missing',self.codes())
    def test_inventory(self):
        self.make(); (self.raw/'missing.docx').write_bytes(b'not extracted')
        self.assertIn('source_not_in_extraction',self.codes())
    def test_outside_resource(self):
        self.make(md='1.1.1. Test text\n\n[bad](../../../../../../etc/passwd)\n')
        self.assertIn('resource_outside_document_folder',self.codes())
    def test_supplementary(self):
        self.make(extras={'word/footnotes.xml':'<w:footnotes xmlns:w="'+W+'">'+para('Footnote')+'</w:footnotes>'})
        self.assertIn('supplementary_parts_not_verified',self.codes())
    def test_cli_report_and_status(self):
        self.make(); before=self.src.read_bytes()
        command=[sys.executable,str(SCRIPT),'--project-root',str(self.root),'--input',self.extracted.relative_to(self.root).as_posix()]
        first=subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(first.returncode,0,first.stderr); printed=json.loads(first.stdout)
        self.assertTrue(Path(printed['report']).is_file())
        self.assertEqual(self.src.read_bytes(),before)
        self.dest.write_text('lost text',encoding='utf-8')
        second=subprocess.run(command,capture_output=True,text=True)
        self.assertEqual(second.returncode,1,second.stderr)
        self.assertNotEqual(json.loads(second.stdout)['report'],printed['report'])

if __name__=='__main__': unittest.main(verbosity=2)

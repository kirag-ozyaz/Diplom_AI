# V2_исправления_1_10 — разбитый набор вопросов + прогресс + отдельная коллекция rerank

Распаковать в корень проекта (рядом с V2). Файлы:
- V2/scripts/build_split_eval/build.py — сборка eval_questions_split.json / eval_qrels_split.json (как в 1_9)
- V2/configs/pipeline_manual_merged_split.json — конфиг набора; rerank → отдельная коллекция diplom_v2_rerank
- V2/src/retrieval_eval/backend.py, clip_backend.py, common.py — строки прогресса (батчи/вопросы, прошло/осталось); логика не менялась

Нужно: openpyxl (сборка), pymilvus + sentence-transformers (поиск), запущенный Milvus.

## 1. Сборка набора (уже сделана; повтор — с --overwrite)
    python V2/scripts/build_split_eval/build.py --project-root . --overwrite
    python V2/scripts/run_pipeline.py validate --config V2/configs/pipeline_manual_merged_split.json

## 2. Загрузка, поиск, оценка (по очереди, с логами)
    mkdir V2\results\logs
    python V2/scripts/run_pipeline.py all --config V2/configs/pipeline_manual_merged_split.json --mode base --allow-db-write 2>&1 | Tee-Object -FilePath V2\results\logs\1_base.log
    python V2/scripts/run_pipeline.py all --config V2/configs/pipeline_manual_merged_split.json --mode e5 --allow-db-write 2>&1 | Tee-Object -FilePath V2\results\logs\2_e5.log
    python V2/scripts/run_pipeline.py all --config V2/configs/pipeline_manual_merged_split.json --mode rerank --allow-db-write 2>&1 | Tee-Object -FilePath V2\results\logs\3_rerank.log
    python V2/scripts/run_pipeline.py load-clip --config V2/configs/pipeline_manual_merged_split.json --allow-db-write 2>&1 | Tee-Object -FilePath V2\results\logs\4_load_clip.log
    python V2/scripts/run_pipeline.py all --config V2/configs/pipeline_manual_merged_split.json --mode rerank --reuse-collection --with-clip 2>&1 | Tee-Object -FilePath V2\results\logs\5_rerank_clip.log

--allow-db-write создаёт коллекцию (если она уже есть — ошибка, ничего не удаляется).
--reuse-collection ищет в существующей. Если коллекция уже создана, повторяйте шаг с --reuse-collection.
Коллекции: diplom_v2_base, diplom_v2_e5, diplom_v2_rerank, diplom_v2_clip.
Каждый шаг all печатает путь к metrics.json.

Пример прогресса:
  [23:52:10] загрузка diplom_v2_base: батч 12/197 (6%), прошло 0:00:41, осталось ~0:10:32
  [23:58:40] поиск diplom_v2_rerank + rerank: вопрос готов 240/720 (33%), прошло 0:03:05, осталось ~0:06:10

Старые eval_questions.json, retrieval_qrels.json и остальные конфиги не изменяются.

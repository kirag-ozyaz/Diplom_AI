$ErrorActionPreference = "Stop"
$Pipeline = Join-Path $PSScriptRoot "run_pipeline.py"
& python $Pipeline load --mode rerank @args
exit $LASTEXITCODE

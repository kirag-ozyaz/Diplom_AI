$ErrorActionPreference = "Stop"
$Pipeline = Join-Path $PSScriptRoot "run_pipeline.py"
& python $Pipeline search --mode base @args
exit $LASTEXITCODE

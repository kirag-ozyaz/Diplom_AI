$ErrorActionPreference = "Stop"
$Pipeline = Join-Path $PSScriptRoot "run_pipeline.py"
& python $Pipeline plan @args
exit $LASTEXITCODE

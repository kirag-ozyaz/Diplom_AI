$ErrorActionPreference = "Stop"
$Pipeline = Join-Path $PSScriptRoot "run_pipeline.py"
& python $Pipeline search --mode e5 @args
exit $LASTEXITCODE

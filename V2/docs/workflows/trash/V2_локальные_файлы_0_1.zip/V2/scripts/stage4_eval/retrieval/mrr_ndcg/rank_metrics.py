"""Общий модуль V2; внутренний API старого проекта не воспроизводится."""
from pathlib import Path
import sys
_V2 = next(p for p in Path(__file__).resolve().parents if (p/'configs/pipeline.json').is_file())
sys.path.insert(0, str(_V2/'src'))
from retrieval_eval.scoring import ranked_metrics, fact_coverage, evaluate

#!/usr/bin/env python3
"""Новая CLI-точка входа V2. Не совместима с внутренним API одноимённого старого модуля."""
import importlib.util
import sys
from pathlib import Path

if __name__ == '__main__':
    v2 = next(p for p in Path(__file__).resolve().parents
              if (p/'configs/pipeline.json').is_file() and (p/'scripts/run_pipeline.py').is_file())
    spec = importlib.util.spec_from_file_location('v2_entrypoint', v2/'scripts/run_pipeline.py')
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    sys.exit(runner.main(['search', '--mode', 'e5'] + sys.argv[1:]))

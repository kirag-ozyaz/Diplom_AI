"""Общий модуль V2; внутренний API старого проекта не воспроизводится."""
from pathlib import Path
import sys
_V2 = next(p for p in Path(__file__).resolve().parents if (p/'configs/pipeline.json').is_file())
sys.path.insert(0, str(_V2/'src'))
from retrieval_eval.common import load_config

def load_runtime_config(project_root=None,config=None):
    return load_config(_V2,project_root,config)

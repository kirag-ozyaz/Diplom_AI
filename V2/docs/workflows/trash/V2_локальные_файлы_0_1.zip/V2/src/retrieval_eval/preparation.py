"""Консервативная подготовка новых чанков из уже извлечённых Markdown.
DOCX, формулы и merged cells здесь не угадываются; используется прежнее извлечение отдельно.
"""
import hashlib
import json
import re
import shutil
from pathlib import Path
from .common import ensure, inside, path_in, write_json, run_id


def prepare_markdown(config, input_path):
    source = path_in(config['_root'], input_path)
    ensure(source.is_dir(), 'Нужна папка подготовленных Markdown')
    target = config['_v2'] / 'data/chunked'
    ensure(inside(target, config['_v2']), 'Выходная папка чанков ссылается за пределы V2')
    ensure(not target.exists() or not any(target.iterdir()),
           'V2/data/chunked не пуста. Подготовка не перезаписывает существующие чанки.')
    ensure(not inside(source, target) and not inside(target, source), 'Источник и выход не должны перекрываться')
    files = sorted(source.rglob('*.md'))
    ensure(bool(files), 'Нет Markdown')
    prepared, warnings = [], []
    # Только начало отдельной строки; строка «см. пункт 1.2.3» не становится владельцем.
    owner = re.compile(r'^\s*(?:#{1,6}\s*)?(\d+\.\d+\.\d+(?:\.\d+)*)(?:\.)?\s+(?=\S)', re.MULTILINE)
    outputs, used_ids = [], set()
    for file in files:
        ensure(inside(file, source), 'Ссылка Markdown вне источника')
        text = file.read_text(encoding='utf-8-sig')
        matches = list(owner.finditer(text))
        if not matches:
            warnings.append({'source': str(file.relative_to(source)), 'problem': 'no_numbered_clause; not_chunked'})
            continue
        if text[:matches[0].start()].strip():
            warnings.append({'source': str(file.relative_to(source)), 'problem': 'preamble_not_indexed; inspect'})
        entries = []
        for i, match in enumerate(matches):
            content = text[match.start():matches[i+1].start() if i+1 < len(matches) else len(text)].strip()
            clause = match.group(1)
            if len(content.encode()) > 65535:
                raise ValueError(f'Пункт {clause} слишком велик: требуется осмысленное разбиение, не обрезка')
            # Ресурсы остаются в исходной папке read-only; переписываем только ссылки новой копии.
            def image_link(m):
                name = m.group(2).strip().strip('<>')
                if name.startswith(('http:', 'https:', 'data:')):
                    warnings.append({'clause': clause, 'problem': 'external_image_not_fetched', 'path': name})
                    return m.group(0)
                asset = (file.parent/name).resolve()
                ensure(inside(asset, config['_root']), 'Ссылка на ресурс вне проекта')
                if not asset.is_file():
                    warnings.append({'clause': clause, 'problem': 'missing_image', 'path': name})
                    return m.group(0)
                import os
                rel = os.path.relpath(asset, target).replace('\\','/')
                return f'![{m.group(1)}]({rel})'
            content = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', image_link, content)
            stem = file.relative_to(source).as_posix()
            cid = 'v2_' + clause + '_' + hashlib.sha256((stem+'\0'+content).encode()).hexdigest()[:24]
            ensure(cid not in used_ids, 'Повтор идентификатора при подготовке')
            used_ids.add(cid)
            entries.append({'id': cid, 'content': content, 'metadata': {
                'Document': stem, 'source_file': file.relative_to(config['_root']).as_posix(),
                'Clause': clause, 'document_version_sha256': hashlib.sha256(text.encode()).hexdigest(),
                'owner_review_status': 'structural_candidate_not_reviewed',
                'contains_tables': '|' in content, 'contains_images': '![' in content,
                'table_ownership': 'requires_review', 'chunking_version': 'v2-markdown-clause-1'}})
        name = hashlib.sha256(file.relative_to(source).as_posix().encode()).hexdigest()[:16]+'.chunked.jsonl'
        outputs.append((target/name, entries))
    ensure(bool(outputs), 'Не удалось выделить ни одного пункта')
    # Сначала подготовить всё в памяти, чтобы ранняя ошибка не оставляла частичный корпус.
    target.mkdir(parents=True, exist_ok=True)
    for path, entries in outputs:
        with path.open('x', encoding='utf-8') as f:
            for row in entries:
                f.write(json.dumps(row, ensure_ascii=False)+'\n')
        prepared.append({'path': path.relative_to(config['_root']).as_posix(), 'chunks': len(entries)})
    return {'files': prepared, 'warnings': warnings,
            'ready_for_final_scoring': False, 'ownership_review_required': True,
            'note': 'Новый корпус не активирован. Требуется проверка границ, таблиц, ресурсов, новая разметка и явная смена paths.chunks/qrels.'}
